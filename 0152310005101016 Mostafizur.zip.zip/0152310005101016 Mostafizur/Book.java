// Subclass inheriting LibraryItem[cite: 1]
public class Book extends LibraryItem {
    private String author;

    // Parameterized Constructor[cite: 1]
    public Book(String id, String title, String author) {
        super(id, title); // Calling parent constructor[cite: 1]
        this.author = author;
    }

    // Copy Constructor[cite: 1]
    public Book(Book otherBook) {
        super(otherBook.getId(), otherBook.getTitle(), otherBook.isAvailable());
        this.author = otherBook.author;
    }

    public String getAuthor() {
        return author;
    }

    // Method Overriding (Polymorphism)[cite: 1]
    @Override
    public void displayInformation() {
        System.out.println("Book ID: " + getId() + " | Title: " + getTitle() + 
                           " | Author: " + author + " | Status: " + (isAvailable() ? "Available" : "Borrowed"));
    }
}
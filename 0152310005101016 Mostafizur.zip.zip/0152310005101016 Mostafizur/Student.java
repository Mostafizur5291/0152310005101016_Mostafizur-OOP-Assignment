import java.util.ArrayList;
import java.util.List;

public class Student extends Person {
    private List<Book> borrowedBooks;

    public Student(String id, String name, String contactInfo) {
        super(id, name, contactInfo);
        this.borrowedBooks = new ArrayList<>();
    }

    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }

    public void borrowBook(Book book) {
        borrowedBooks.add(book);
        book.setAvailable(false);
    }

    public boolean returnBook(String bookId) {
        for (Book b : borrowedBooks) {
            if (b.getId().equalsIgnoreCase(bookId)) {
                borrowedBooks.remove(b);
                b.setAvailable(true);
                return true;
            }
        }
        return false;
    }

    @Override
    public void displayInformation() {
        System.out.println("Student ID: " + getId() + " | Name: " + getName() + 
                           " | Contact: " + getContactInfo() + " | Total Borrowed: " + borrowedBooks.size());
    }
}
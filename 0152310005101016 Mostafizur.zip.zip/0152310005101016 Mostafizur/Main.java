import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// ==========================================
// 3.8 Abstract Class & 3.9 Static Member
// ==========================================
abstract class LibraryItem {
    private String id;
    private String title;
    private boolean isAvailable;
    
    // Static member to track total library items [Req 3.9]
    private static int totalItemsCount = 0;

    // Parameterized Constructor
    public LibraryItem(String id, String title) {
        this.id = id;               // Demonstrating 'this' keyword [Req 3.7]
        this.title = title;
        this.isAvailable = true;
        totalItemsCount++;          // Increment static counter
    }

    // Overloaded Constructor [Req 3.5]
    public LibraryItem(String id, String title, boolean isAvailable) {
        this.id = id;
        this.title = title;
        this.isAvailable = isAvailable;
        totalItemsCount++;
    }

    // Abstract Method [Req 3.8]
    public abstract void displayInformation();

    // Getters and Setters (Encapsulation) [Req 3.6]
    public String getId() { return id; }
    public String getTitle() { return title; }
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }

    public static int getTotalItemsCount() {
        return totalItemsCount;
    }
}

// ==========================================
// Subclass 1: Book (Inherits LibraryItem)
// ==========================================
class Book extends LibraryItem {
    private String author;

    // Parameterized Constructor using 'super' [Req 3.3, 3.7]
    public Book(String id, String title, String author) {
        super(id, title);           // Call superclass constructor [Req 3.7]
        this.author = author;
    }

    // Copy Constructor [Req 3.5]
    public Book(Book otherBook) {
        super(otherBook.getId(), otherBook.getTitle(), otherBook.isAvailable());
        this.author = otherBook.author;
    }

    public String getAuthor() { return author; }

    // Polymorphism: Method Overriding [Req 3.4]
    @Override
    public void displayInformation() {
        System.out.println("Book ID: " + getId() + " | Title: " + getTitle() + 
                           " | Author: " + author + " | Available: " + (isAvailable() ? "Yes" : "No"));
    }
}

// ==========================================
// Subclass 2: Magazine (Justification of Hierarchy)
// ==========================================
class Magazine extends LibraryItem {
    private int issueNumber;

    public Magazine(String id, String title, int issueNumber) {
        super(id, title);
        this.issueNumber = issueNumber;
    }

    @Override
    public void displayInformation() {
        System.out.println("Magazine ID: " + getId() + " | Title: " + getTitle() + 
                           " | Issue No: " + issueNumber + " | Available: " + (isAvailable() ? "Yes" : "No"));
    }
}

// ==========================================
// 3.1 & 3.3 Person Class (Base Class for Users)
// ==========================================
abstract class Person {
    private String id;
    private String name;
    private String contactInfo;

    // Parameterized Constructor
    public Person(String id, String name, String contactInfo) {
        this.id = id;               // 'this' keyword
        this.name = name;
        this.contactInfo = contactInfo;
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getContactInfo() { return contactInfo; }

    // Abstract method for Polymorphism [Req 3.4]
    public abstract void displayInformation();
}

// ==========================================
// Subclass: Student (Inherits Person)
// ==========================================
class Student extends Person {
    private List<Book> borrowedBooks;

    public Student(String id, String name, String contactInfo) {
        super(id, name, contactInfo); // Call parent constructor
        this.borrowedBooks = new ArrayList<>();
    }

    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }

    public void borrowBook(Book book) {
        borrowedBooks.add(book);
        book.setAvailable(false);
    }

    public boolean returnBook(String bookId) {
        for (Book book : borrowedBooks) {
            if (book.getId().equalsIgnoreCase(bookId)) {
                borrowedBooks.remove(book);
                book.setAvailable(true);
                return true;
            }
        }
        return false;
    }

    @Override
    public void displayInformation() {
        System.out.println("Student ID: " + getId() + " | Name: " + getName() + 
                           " | Contact: " + getContactInfo() + " | Borrowed Books: " + borrowedBooks.size());
    }
}

// ==========================================
// Subclass: Librarian (Inherits Person)
// ==========================================
class Librarian extends Person {
    private String employeeId;

    public Librarian(String id, String name, String contactInfo, String employeeId) {
        super(id, name, contactInfo);
        this.employeeId = employeeId;
    }

    @Override
    public void displayInformation() {
        System.out.println("Librarian ID: " + getId() + " | Name: " + getName() + 
                           " | Employee ID: " + employeeId + " | Contact: " + getContactInfo());
    }
}

// ==========================================
// 3.10 Main Class with Menu-Driven Program
// ==========================================
public class Main {
    private static List<LibraryItem> items = new ArrayList<>();
    private static List<Student> students = new ArrayList<>();
    private static Librarian librarian = new Librarian("L01", "Admin Librarian", "admin@univ.edu", "EMP100");
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Pre-populating Data
        items.add(new Book("B101", "Java Programming", "James Gosling"));
        items.add(new Book("B102", "Data Structures", "Robert Lafore"));
        items.add(new Magazine("M101", "Tech Monthly", 45));

        students.add(new Student("S101", "Rahim Ahmed", "rahim@mail.com"));
        students.add(new Student("S102", "Karim Uddin", "karim@mail.com"));

        while (true) {
            System.out.println("\n=== UNIVERSITY LIBRARY MANAGEMENT ===");
            System.out.println("Select User Type:");
            System.out.println("1. Student");
            System.out.println("2. Librarian");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    studentLogin();
                    break;
                case 2:
                    librarianMenu();
                    break;
                case 3:
                    System.out.println("Exiting System. Good Bye!");
                    return;
                default:
                    System.out.println("Invalid Choice! Please try again.");
            }
        }
    }

    // ---------------- STUDENT FLOW ----------------
    private static void studentLogin() {
        System.out.print("Enter your Student ID (e.g., S101): ");
        String sId = scanner.nextLine();
        Student student = findStudent(sId);

        if (student == null) {
            System.out.println("Student not found!");
            return;
        }

        while (true) {
            System.out.println("\n--- STUDENT MENU ---");
            System.out.println("1. View Available Books");
            System.out.println("2. Search Book");
            System.out.println("3. Borrow Book");
            System.out.println("4. Return Book");
            System.out.println("5. View My Borrowed Books");
            System.out.println("6. View My Profile");
            System.out.println("7. Logout");
            System.out.print("Enter your choice: ");

            int choice = getIntInput();
            switch (choice) {
                case 1:
                    viewAvailableBooks();
                    break;
                case 2:
                    searchBook();
                    break;
                case 3:
                    borrowBook(student);
                    break;
                case 4:
                    returnBook(student);
                    break;
                case 5:
                    viewStudentBorrowedBooks(student);
                    break;
                case 6:
                    student.displayInformation();
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    // ---------------- LIBRARIAN FLOW ----------------
    private static void librarianMenu() {
        while (true) {
            System.out.println("\n--- LIBRARIAN MENU ---");
            System.out.println("1. Add New Book");
            System.out.println("2. Remove Book");
            System.out.println("3. View All Books");
            System.out.println("4. Search Book");
            System.out.println("5. Register Student");
            System.out.println("6. View All Students");
            System.out.println("7. View Borrowed Books");
            System.out.println("8. View Available Books");
            System.out.println("9. View Library Statistics");
            System.out.println("10. Logout");
            System.out.print("Enter your choice: ");

            int choice = getIntInput();
            switch (choice) {
                case 1:
                    addNewBook();
                    break;
                case 2:
                    removeBook();
                    break;
                case 3:
                    viewAllBooks();
                    break;
                case 4:
                    searchBook();
                    break;
                case 5:
                    registerStudent();
                    break;
                case 6:
                    viewAllStudents();
                    break;
                case 7:
                    viewAllBorrowedBooks();
                    break;
                case 8:
                    viewAvailableBooks();
                    break;
                case 9:
                    System.out.println("Total Registered Library Items: " + LibraryItem.getTotalItemsCount());
                    System.out.println("Total Registered Students: " + students.size());
                    break;
                case 10:
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    // ---------------- HELPER METHODS ----------------
    private static void viewAvailableBooks() {
        System.out.println("\n-- Available Books --");
        boolean found = false;
        for (LibraryItem item : items) {
            if (item instanceof Book && item.isAvailable()) { // Polymorphism usage
                item.displayInformation();
                found = true;
            }
        }
        if (!found) System.out.println("No books available right now.");
    }

    private static void viewAllBooks() {
        System.out.println("\n-- All Items in Library --");
        for (LibraryItem item : items) {
            item.displayInformation(); // Polymorphism
        }
    }

    private static void searchBook() {
        System.out.print("Enter Book Title or Author to search: ");
        String query = scanner.nextLine().toLowerCase();
        boolean found = false;

        for (LibraryItem item : items) {
            if (item instanceof Book) {
                Book b = (Book) item;
                if (b.getTitle().toLowerCase().contains(query) || b.getAuthor().toLowerCase().contains(query)) {
                    b.displayInformation();
                    found = true;
                }
            }
        }
        if (!found) System.out.println("No matching books found.");
    }

    private static void borrowBook(Student student) {
        System.out.print("Enter Book ID to Borrow: ");
        String bId = scanner.nextLine();
        for (LibraryItem item : items) {
            if (item instanceof Book && item.getId().equalsIgnoreCase(bId)) {
                Book book = (Book) item;
                if (book.isAvailable()) {
                    student.borrowBook(book);
                    System.out.println("Book borrowed successfully!");
                } else {
                    System.out.println("Sorry, book is already borrowed!");
                }
                return;
            }
        }
        System.out.println("Book ID not found!");
    }

    private static void returnBook(Student student) {
        System.out.print("Enter Book ID to Return: ");
        String bId = scanner.nextLine();
        if (student.returnBook(bId)) {
            System.out.println("Book returned successfully!");
        } else {
            System.out.println("You haven't borrowed this book!");
        }
    }

    private static void viewStudentBorrowedBooks(Student student) {
        System.out.println("\n-- My Borrowed Books --");
        if (student.getBorrowedBooks().isEmpty()) {
            System.out.println("You have not borrowed any books.");
        } else {
            for (Book b : student.getBorrowedBooks()) {
                b.displayInformation();
            }
        }
    }

    private static void addNewBook() {
        System.out.print("Enter Book ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Book Title: ");
        String title = scanner.nextLine();
        System.out.print("Enter Author: ");
        String author = scanner.nextLine();

        items.add(new Book(id, title, author));
        System.out.println("Book added successfully!");
    }

    private static void removeBook() {
        System.out.print("Enter Book ID to remove: ");
        String id = scanner.nextLine();
        LibraryItem target = null;
        for (LibraryItem item : items) {
            if (item.getId().equalsIgnoreCase(id)) {
                target = item;
                break;
            }
        }
        if (target != null) {
            items.remove(target);
            System.out.println("Item removed successfully!");
        } else {
            System.out.println("Item not found!");
        }
    }

    private static void registerStudent() {
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Contact Info: ");
        String contact = scanner.nextLine();

        students.add(new Student(id, name, contact));
        System.out.println("Student registered successfully!");
    }

    private static void viewAllStudents() {
        System.out.println("\n-- Registered Students --");
        for (Student s : students) {
            s.displayInformation();
        }
    }

    private static void viewAllBorrowedBooks() {
        System.out.println("\n-- All Borrowed Books --");
        boolean any = false;
        for (Student s : students) {
            for (Book b : s.getBorrowedBooks()) {
                System.out.print("Borrowed by " + s.getName() + " (" + s.getId() + ") -> ");
                b.displayInformation();
                any = true;
            }
        }
        if (!any) System.out.println("No books are currently borrowed.");
    }

    private static Student findStudent(String id) {
        for (Student s : students) {
            if (s.getId().equalsIgnoreCase(id)) return s;
        }
        return null;
    }

    private static int getIntInput() {
        try {
            int val = Integer.parseInt(scanner.nextLine());
            return val;
        } catch (Exception e) {
            return -1;
        }
    }
}
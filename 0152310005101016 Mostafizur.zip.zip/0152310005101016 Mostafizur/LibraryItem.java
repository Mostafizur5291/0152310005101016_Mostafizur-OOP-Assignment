// Abstract Class for all library items
public abstract class LibraryItem {
    private String id;
    private String title;
    private boolean isAvailable;
    
    // Static variable to track total items created
    private static int totalItemsCount = 0;

    // Parameterized Constructor
    public LibraryItem(String id, String title) {
        this.id = id;               // 'this' keyword demo
        this.title = title;
        this.isAvailable = true;
        totalItemsCount++;          // Increment count
    }

    // Overloaded Constructor
    public LibraryItem(String id, String title, boolean isAvailable) {
        this.id = id;
        this.title = title;
        this.isAvailable = isAvailable;
        totalItemsCount++;
    }

    // Abstract Method
    public abstract void displayInformation();

    // Getter and Setter methods (Encapsulation)
    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public static int getTotalItemsCount() {
        return totalItemsCount;
    }
}
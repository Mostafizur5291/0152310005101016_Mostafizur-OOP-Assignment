public class Librarian extends Person {
    private String empId;

    public Librarian(String id, String name, String contactInfo, String empId) {
        super(id, name, contactInfo);
        this.empId = empId;
    }

    @Override
    public void displayInformation() {
        System.out.println("Librarian ID: " + getId() + " | Name: " + getName() + 
                           " | Emp ID: " + empId + " | Contact: " + getContactInfo());
    }
}
// Base class for users[cite: 1]
public abstract class Person {
    private String id;
    private String name;
    private String contactInfo;

    public Person(String id, String name, String contactInfo) {
        this.id = id;
        this.name = name;
        this.contactInfo = contactInfo;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    // Abstract method for polymorphism[cite: 1]
    public abstract void displayInformation();
}